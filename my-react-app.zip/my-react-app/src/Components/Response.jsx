import React, { useState } from "react";

const Response = () => {
  const [selectedDay, setSelectedDay] = useState(1);
  const [isExpanded, setIsExpanded] = useState(false);

  // Mock travel data - replace with actual API response
  const travelData = {
    destination: "Paris, France",
    duration: "5 days",
    budget: "$2,500",
    itinerary: [
      {
        day: 1,
        title: "Arrival & Eiffel Tower",
        activities: [
          "Check into your hotel in the 7th arrondissement",
          "Visit the iconic Eiffel Tower (book tickets in advance)",
          "Evening Seine River cruise",
          "Dinner at a traditional French bistro",
        ],
        image: "🗼",
        time: "Full Day",
      },
      {
        day: 2,
        title: "Art & Culture Day",
        activities: [
          "Morning at the Louvre Museum",
          "Walk through Tuileries Garden",
          "Visit Notre-Dame Cathedral",
          "Explore the Latin Quarter",
        ],
        image: "🎨",
        time: "Full Day",
      },
      {
        day: 3,
        title: "Champs-Élysées & Shopping",
        activities: [
          "Arc de Triomphe visit",
          "Walk down Champs-Élysées",
          "Shopping at Galeries Lafayette",
          "Evening at Montmartre",
        ],
        image: "🛍️",
        time: "Full Day",
      },
      {
        day: 4,
        title: "Palace of Versailles",
        activities: [
          "Day trip to Palace of Versailles",
          "Explore the magnificent gardens",
          "Return to Paris for dinner",
          "Optional: Moulin Rouge show",
        ],
        image: "🏰",
        time: "Full Day",
      },
      {
        day: 5,
        title: "Final Day & Departure",
        activities: [
          "Visit Sacré-Cœur Basilica",
          "Last-minute shopping",
          "Farewell lunch at a café",
          "Transfer to airport",
        ],
        image: "✈️",
        time: "Half Day",
      },
    ],
  };

  return (
    <div className="w-full space-y-6">
      {/* Header Card */}
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/20">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center text-white text-2xl">
              🌍
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-800">
                {travelData.destination}
              </h2>
              <p className="text-gray-600">
                Your personalized travel itinerary
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-500">Duration</div>
            <div className="text-lg font-semibold text-gray-800">
              {travelData.duration}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-4">
            <div className="flex items-center space-x-2">
              <span className="text-blue-600">📅</span>
              <span className="font-semibold text-gray-800">Duration</span>
            </div>
            <p className="text-gray-600 mt-1">{travelData.duration}</p>
          </div>
          <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-xl p-4">
            <div className="flex items-center space-x-2">
              <span className="text-green-600">💰</span>
              <span className="font-semibold text-gray-800">Budget</span>
            </div>
            <p className="text-gray-600 mt-1">{travelData.budget}</p>
          </div>
          <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl p-4">
            <div className="flex items-center space-x-2">
              <span className="text-purple-600">⭐</span>
              <span className="font-semibold text-gray-800">Rating</span>
            </div>
            <p className="text-gray-600 mt-1">4.8/5.0</p>
          </div>
        </div>
      </div>

      {/* Day Navigation */}
      <div className="flex flex-wrap gap-2 justify-center">
        {travelData.itinerary.map((day) => (
          <button
            key={day.day}
            onClick={() => setSelectedDay(day.day)}
            className={`px-4 py-2 rounded-xl font-medium transition-all duration-300 ${
              selectedDay === day.day
                ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
                : "bg-white/60 backdrop-blur-sm text-gray-600 hover:bg-white/80 border border-white/20"
            }`}
          >
            Day {day.day}
          </button>
        ))}
      </div>

      {/* Itinerary Details */}
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/20">
        {travelData.itinerary.map((day) => (
          <div
            key={day.day}
            className={selectedDay === day.day ? "block" : "hidden"}
          >
            <div className="flex items-center space-x-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center text-white text-3xl">
                {day.image}
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-800">
                  {day.title}
                </h3>
                <p className="text-gray-600 flex items-center space-x-2">
                  <span>⏰</span>
                  <span>{day.time}</span>
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {day.activities.map((activity, index) => (
                <div
                  key={index}
                  className="flex items-start space-x-3 p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl hover:from-blue-50 hover:to-purple-50 transition-all duration-300"
                >
                  <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-xs font-bold mt-1">
                    {index + 1}
                  </div>
                  <p className="text-gray-700 flex-1">{activity}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Expandable Tips Section */}
      <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/20">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full flex items-center justify-between text-left"
        >
          <div className="flex items-center space-x-3">
            <span className="text-2xl">💡</span>
            <h3 className="text-xl font-bold text-gray-800">
              Travel Tips & Recommendations
            </h3>
          </div>
          <span
            className={`text-2xl transition-transform duration-300 ${
              isExpanded ? "rotate-180" : ""
            }`}
          >
            ▼
          </span>
        </button>

        {isExpanded && (
          <div className="mt-4 space-y-3 animate-fade-in">
            <div className="p-4 bg-yellow-50 rounded-xl border-l-4 border-yellow-400">
              <p className="text-gray-700">
                <strong>Best Time to Visit:</strong> Spring (April-June) or Fall
                (September-November) for pleasant weather and fewer crowds.
              </p>
            </div>
            <div className="p-4 bg-blue-50 rounded-xl border-l-4 border-blue-400">
              <p className="text-gray-700">
                <strong>Transportation:</strong> Purchase a Paris Visite pass
                for unlimited metro and bus rides.
              </p>
            </div>
            <div className="p-4 bg-green-50 rounded-xl border-l-4 border-green-400">
              <p className="text-gray-700">
                <strong>Dining:</strong> Book restaurants in advance, especially
                for dinner. Try local bistros for authentic French cuisine.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Response;
